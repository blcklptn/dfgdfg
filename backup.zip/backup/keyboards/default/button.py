from aiogram.types import KeyboardButton, ReplyKeyboardMarkup

menu_button_start = ReplyKeyboardMarkup(
    [
        [
            KeyboardButton(text='😏Инвайт'),
            KeyboardButton(text='😡Жалобы'),

        ],
        [
            KeyboardButton(text='😼Просмотры'),
            KeyboardButton(text='👺Первонахер'),
        ],
        [
            KeyboardButton(text='👨‍💻Рассылка сообщений'),
            KeyboardButton(text='🧔🏿Вступление/выход из группы и чата'),
        ],
        [
            KeyboardButton(text='🗣Голосования опросы'),
            KeyboardButton(text='👍Реакции'),
        ],
        [
            KeyboardButton(text='👾Проверка номеров'),
            KeyboardButton(text='🧩Прокси'),
            KeyboardButton(text='📲Смена api hash'),
        ],


    ],
    resize_keyboard=True)

stop_button = ReplyKeyboardMarkup(
    [
        [
            KeyboardButton(text='СТОП ⛔'),
        ],

    ],
    resize_keyboard=True)

menu_button_reporter = ReplyKeyboardMarkup(
    [
        [
            KeyboardButton(text='Спам'),
            KeyboardButton(text='Насилие'),

        ],
        [
            KeyboardButton(text='Детская порнография'),
            KeyboardButton(text='Порнография'),

        ],
        [
            KeyboardButton(text='Авторское права'),
            KeyboardButton(text='Наркотики'),

        ],
        [
            KeyboardButton(text='Личные данные'),
            KeyboardButton(text='Другое'),

        ],
    ],
    resize_keyboard=True)