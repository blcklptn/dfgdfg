import random
import typing
from telethon.tl.types import InputPhoneContact
from telethon import functions
import phonenumbers

from loader import client


def check_phone_number(phone_number: str) -> typing.Optional[str]:
    try:
        return carrier._is_mobile(number_type(phonenumbers.parse(phone_number)))
    except phonenumbers.phonenumberutil.NumberParseException:
        return None


async def check_contact_by_phone_number(phone_number: str) -> str:
    """
    Проверяет, есть ли контакт с указанным номером телефона в Telegram

    :param phone_number: Номер телефона, начинающийся с +
    """

    try:
        contact = InputPhoneContact(client_id=random.randrange(-2 ** 63, 2 ** 63), phone=phone_number[1:],
                                    first_name="", last_name="")
        contacts = await client(functions.contacts.ImportContactsRequest([contact]))
        print(contacts)
        print(contacts.to_dict())
        print(contacts.to_dict()["users"])
        print(contacts.to_dict()["users"][0])
        print(contacts.to_dict()["users"][0]["username"])
        username = contacts.to_dict()['users'][0]['username']
    except Exception as e:
        print(e)
        raise exceptions.TelegramContactError

    if not username:
        raise exceptions.TelegramContactNoUsername

    # Добавили контакт, а теперь удаляем его
    try:
        await client(functions.contacts.DeleteContactsRequest(id=[username]))
    except:
        pass

    return username
