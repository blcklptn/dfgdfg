import asyncio
import csv
import os
import random
import re
import shutil
import zipfile

import telethon
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.builtin import CommandStart
from aiogram.types import ContentType, ReplyKeyboardRemove
from telethon import TelegramClient
from telethon.tl.functions.channels import JoinChannelRequest, InviteToChannelRequest, LeaveChannelRequest
from telethon.tl.functions.contacts import ResolveUsernameRequest
from telethon.tl.types import InputPeerChannel, InputUser

from keyboards.default.button import stop_button, menu_button_start
from loader import dp



@dp.message_handler(state='getgroup_stat_1', content_types=ContentType.DOCUMENT)
async def waiting_chat(message: types.Message, state: FSMContext):
    name_of_file = f'txt_{message.from_user.id}.txt'
    txt_path = f'sessions/{name_of_file}'
    await message.document.download(txt_path)

    await state.update_data(messerror=txt_path)
    await state.set_state('getgroup_stat_2')
    await message.answer('Отправьте ZIP-архив с сессиями')


@dp.message_handler(state='getgroup_stat_2', content_types=ContentType.DOCUMENT)
async def waiting_chat(message: types.Message, state: FSMContext):
    name_of_file = f'zip_{message.from_user.id}.zip'
    await message.document.download(name_of_file)
    session_path = f'sessions'
    file = zipfile.ZipFile(name_of_file)
    file.extractall(session_path)
    file.close()
    os.remove(name_of_file)
    sessions = os.listdir(session_path)
    await state.update_data(sessions=sessions)

    data = await state.get_data()
    sessions = data['sessions']
    path_messerror = data['messerror']
    with open(path_messerror, newline='\n', encoding='utf-8') as csvfile:
        coommments = csvfile.readlines()
        coommments = [com.rstrip() for com in coommments if com]
    loop = asyncio.get_event_loop()
    for i in sessions:
        asyncio.ensure_future(ingroupUP(message.from_user.id, i,coommments))
    try:
        loop.run_forever()
    except Exception as E:
        print(E)

    await message.answer('Люди вступили успешно завершены.')
    await state.finish()

async def ingroupUP(us_id,i,coommments):
    client = TelegramClient(f'sessions/{us_id}/{i}', 10245235, '95db77689e2aae95cfbdcb92de1a36e1')
    await client.connect()
    auth = await client.is_user_authorized()
    if not auth:
        client.disconnect()
    else:
        for j in coommments:
            try:
                await client(JoinChannelRequest(j))
            except Exception as E:
                try:
                    await client(LeaveChannelRequest(j))
                except:
                    pass
        try:
            client.disconnect()
        except Exception as E:
            print(E)