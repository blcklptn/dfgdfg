import asyncio
import csv
import os
import random
import re
import shutil
import zipfile

import telethon
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.builtin import CommandStart
from aiogram.types import ContentType, ReplyKeyboardRemove
from telethon import TelegramClient
from telethon.tl.functions.channels import JoinChannelRequest, InviteToChannelRequest
from telethon.tl.functions.contacts import ResolveUsernameRequest
from telethon.tl.types import InputPeerChannel, InputUser

from keyboards.default.button import stop_button, menu_button_start
from loader import dp


@dp.message_handler(state='chekingnomber_stat_1')
async def waiting_chat(message: types.Message, state: FSMContext):
    answer_t_1 = message.text

    await state.update_data(chat_id=answer_t_1)

    await message.answer('До 02.04.2022 23:00 в разработке...🧔🏿')

    await state.finish()


