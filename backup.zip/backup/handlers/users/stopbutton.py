from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import ReplyKeyboardRemove

from loader import dp


@dp.message_handler(text='СТОП ⛔', state='*')
async def bot_stop(message: types.Message, state: FSMContext):
    print('g')
    st = await state.get_state()
    print(st)
    await state.finish()
    await message.answer('Инвайтинг завершен', reply_markup=ReplyKeyboardRemove())
