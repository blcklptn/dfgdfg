import asyncio
import csv
import os
import random
import re
import shutil
import subprocess
import zipfile

import telethon
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.builtin import CommandStart
from aiogram.types import ContentType, ReplyKeyboardRemove
from telethon import TelegramClient
from telethon.tl.functions.channels import JoinChannelRequest, InviteToChannelRequest
from telethon.tl.functions.contacts import ResolveUsernameRequest
from telethon.tl.types import InputPeerChannel, InputUser

from data.setting import update_setting
from keyboards.default.button import stop_button, menu_button_start
from loader import dp


@dp.message_handler(state='pervona_stat_1', content_types=ContentType.DOCUMENT)
async def waiting_chat(message: types.Message, state: FSMContext):
    name_of_file = f'txt_{message.from_user.id}_group.txt'
    txt_path = f'C:/Users/th3en/Documents/bots/backup/sessions/{name_of_file}'
    print(txt_path)
    await message.document.download(txt_path)
    await state.update_data(chat_id=txt_path)
    await state.set_state('pervona_stat_2')
    await message.answer('Укажите кол-во комментарий, одной цифрой.!!')


@dp.message_handler(state='pervona_stat_2')
async def waiting_chat(message: types.Message, state: FSMContext):
    if message.text.isdigit():
        await state.update_data(count=message.text)
        await message.answer('Отправьте файл с комментариями в формате .txt')

        await state.set_state('pervona_stat_3')
    else:
        await message.answer('Принимаем только цифры.')

@dp.message_handler(state='pervona_stat_3', content_types=ContentType.DOCUMENT)
async def waiting_chat(message: types.Message, state: FSMContext):
    
    name_of_file = f'txt_{message.from_user.id}.txt'
    txt_path = f'C:/Users/th3en/Documents/bots/backup/sessions/{name_of_file}'
    await message.document.download(txt_path)
    await state.update_data(messerror=txt_path)
    await state.set_state('pervona_stat_4')
    await message.answer('Отправьте файл с сессиями ZIP.')
    

@dp.message_handler(state='pervona_stat_4', content_types=ContentType.DOCUMENT)
async def waiting_chat(message: types.Message, state: FSMContext):
    await message.answer("STATE 4")
    name_of_file = f'zip_{message.from_user.id}.zip'
    await message.document.download(name_of_file)
    session_path = f'C:/Users/th3en/Documents/bots/backup/sessions/'
    file = zipfile.ZipFile(name_of_file)
    file.extractall(session_path)
    file.close()
    os.remove(name_of_file)
    sessions = os.listdir(session_path)
    await state.update_data(sessions=sessions)

    data = await state.get_data()
    chat_id = data['chat_id']
    count = data['count']
    sessions = data['sessions']
    path_messerror = data['messerror']
    with open(path_messerror, newline='\n', encoding='utf-8') as csvfile:
        coommments = csvfile.readlines()
        coommments = [com.rstrip() for com in coommments if com]

    with open(chat_id, newline='\n', encoding='utf-8') as csvfile:
        chat_id_save = csvfile.readlines()
        chat_id_save = [com.rstrip() for com in chat_id_save if com]

    path = "C:/Users/th3en/Documents/bots/backup/data/settings.ini"
    update_setting(path, 'Pervonaxer', 'chat_id', "~".join(chat_id_save))
    update_setting(path, 'Pervonaxer', 'count', count)
    update_setting(path, 'Pervonaxer', 'sessions', ":".join(sessions))
    update_setting(path, 'Pervonaxer', 'coommments', ":".join(coommments))
    await message.answer(f'<b>Ваш чат/группа: <code>{chat_id}</code>\n'
                         f'Кол-во комментариев: <code>{count}</code>\n'
                         f'Кол-во аккаунтов: <code>{len(sessions)}</code>\n'
                         f'Вариаций комментариев: <code>{len(coommments) - 1}</code>\n'
                         f'</b>\n')
    proj = subprocess.Popen("python pervonaxrun.py", shell=True)
    update_setting(path, 'Pervonaxer', 'pid', f"{proj.pid}")

    await message.answer(f'<b>Все данные записал и 👺Первонахер👺 запустил!</b>\n')