import asyncio
import csv
import os
import random
import re
import shutil
import zipfile

import telethon
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import ContentType
from telethon import TelegramClient
from telethon.tl import functions
from telethon.tl.types import InputReportReasonSpam

from keyboards.default.button import stop_button, menu_button_start, menu_button_reporter
from loader import dp


@dp.message_handler(state='complaints_stat_1')
async def waiting_chat(message: types.Message, state: FSMContext):


    if message.forward_from_chat:
        await state.update_data(forward_from_chat_id=message.forward_from_chat.id)
        await state.update_data(forward_from_chat_username=message.forward_from_chat.username)
        await state.set_state('complaints_stat_2')
    else:
        chat_id = message.text.replace('@', '').replace('/', '')
        chat_id = re.sub(r'\W|(t.me)|(https)|(http)', '', chat_id)
        await state.update_data(chat_id=chat_id)
        await state.set_state('complaints_stat_2')

    await state.set_state('complaints_stat_2')
    await message.answer('Укажите кол-во жалоб')

    # await state.update_data(chat_id=chat_id)
    # data = await state.get_data()
    #await state.set_state('complaints_stat_1')


@dp.message_handler(state='complaints_stat_2')
async def waiting_chat(message: types.Message, state: FSMContext):
    await state.update_data(count=message.text)
    await state.set_state('complaints_stat_3')
    await message.answer('Укажите причину на выбор:',reply_markup=menu_button_reporter)


@dp.message_handler(state='complaints_stat_3')
async def waiting_chat(message: types.Message, state: FSMContext):
    await state.update_data(error=message.text)
    await state.set_state('complaints_stat_4')
    await message.answer('Укажите комментарий к жалобе, в файлом .txt',reply_markup=menu_button_start)


@dp.message_handler(state='complaints_stat_4', content_types=ContentType.DOCUMENT)
async def waiting_chat(message: types.Message, state: FSMContext):
    name_of_file = f'txt_{message.from_user.id}.txt'
    await message.document.download(name_of_file)
    txt_path = f'sessions/{name_of_file}'
    await state.update_data(messerror=txt_path)
    await state.set_state('complaints_stat_5')
    await message.answer('Отправьте ZIP-архив с сессиями')


@dp.message_handler(state='complaints_stat_5', content_types=ContentType.DOCUMENT)
async def waiting_chat(message: types.Message, state: FSMContext):
    name_of_file = f'zip_{message.from_user.id}.zip'
    await message.document.download(name_of_file)
    session_path = f'sessions/{message.from_user.id}'
    file = zipfile.ZipFile(name_of_file)
    file.extractall(session_path)
    file.close()
    os.remove(name_of_file)
    sessions = os.listdir(session_path)
    await state.update_data(sessions=sessions)

    data = await state.get_data()

    await message.answer('Отправка пошла')
    for i in sessions:

        client = TelegramClient(f'sessions/{message.from_user.id}/{i}', 10245235, '95db77689e2aae95cfbdcb92de1a36e1')
        await client.connect()
        auth = await client.is_user_authorized()
        if not auth:
            client.disconnect()
        else:
            result = client(functions.account.ReportPeerRequest(
                peer=data['chat_id'],
                reason=InputReportReasonSpam(),
                message='Оскорбление РФ'
            ))
    await message.answer('Отправка завершенна успеша')
    await state.finish()