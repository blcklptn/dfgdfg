import asyncio
import csv
from http import client
import os
import random
import re
import shutil
import signal
import subprocess
import zipfile

import telethon
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.builtin import CommandStart
from aiogram.types import ContentType, ReplyKeyboardRemove
from telethon import TelegramClient
from telethon.tl.functions.channels import JoinChannelRequest, InviteToChannelRequest
from telethon.tl.functions.contacts import ResolveUsernameRequest
from telethon.tl.types import InputPeerChannel, InputUser

from data.setting import get_setting
from keyboards.default.button import stop_button, menu_button_start
from loader import dp
from handlers.users import pervonaxer

@dp.message_handler(CommandStart(), state='*')
async def bot_start(message: types.Message, state: FSMContext):
    await message.answer(f"Привет, {message.from_user.full_name}!!",reply_markup=menu_button_start)


# invater.py
@dp.message_handler(text='😏Инвайт', state='*')
async def waiting_chat(message: types.Message, state: FSMContext):
    await state.set_state('waiting_chat')

    await message.answer('<b>Отправьте ссылку на группу на 😏Инвайт 😏</b>\n\n'
                         'Примеры:\n'
                         'https://t.me/chatname\n'
                         '@chatname\n'
                         'chatname')


# complaints.py
@dp.message_handler(text='😡Жалобы', state='*')
async def waiting_chat(message: types.Message, state: FSMContext):
    await state.set_state('complaints_stat_1')

    await message.answer('<b>Отправьте ссылку на группу на 😡Жалобы😡</b>\n\n'
                         'Примеры:\n'
                         'https://t.me/chatname\n'
                         '@chatname\n'
                         'chatname')

    await message.answer('Что бы отправить на сообщение, просто перешлите его')


# viewss.py
@dp.message_handler(text='😼Просмотры', state='*')
async def waiting_chat(message: types.Message, state: FSMContext):
    await state.set_state('viewss_stat_1')

    await message.answer('<b>Отправьте ссылку на группу на 😼Просмотры😼</b>\n\n'
                         'Примеры:\n'
                         'https://t.me/chatname\n'
                         '@chatname\n'
                         'chatname')

    await message.answer('Что бы увеличить просмотры на сообщение, просто перешлите его')

# pervonaxer.py
@dp.message_handler(text='👺Первонахер', state='*')
async def waiting_chat(message: types.Message, state: FSMContext):
    await message.answer("Pervonaher")
    await state.set_state('pervona_stat_1')
    try:
        path = "C:/Users/th3en/Documents/bots/backup/data/settings.ini"

        pid = get_setting(path, 'Pervonaxer', 'pid')
        os.kill(int(pid), signal.SIGTERM)
    except Exception as E:
        print(E)
    await message.answer('<b>Отправьте ссылку на группу на 👺Первонахер👺 в формате .txt</b>\n\n'
                         'Примеры:\n'
                         'https://t.me/chatname\n'
                         '@chatname\n'
                         'chatname')



# spammer.py
@dp.message_handler(text='👨‍💻Рассылка сообщений', state='*')
async def waiting_chat(message: types.Message, state: FSMContext):
    await state.set_state('spammer_stat_1')

    await message.answer('<b>Вы перешли в раздел 👨‍💻Рассылки сообщений👨‍💻\n'
                         'Отправьте .CSV файл с юзернеймами</b>\n\n')

# getgroup.py
@dp.message_handler(text='🧔🏿Вступление/выход из группы и чата', state='*')
async def waiting_chat(message: types.Message, state: FSMContext):
    await state.set_state('getgroup_stat_1')

    await message.answer('<b>Отправьте список для 🧔🏿Вступление/выход из группы и чата в формате .txt</b>\n\n')

# voting.py
@dp.message_handler(text='🗣Голосования опросы', state='*')
async def waiting_chat(message: types.Message, state: FSMContext):
    await state.set_state('voting_stat_1')

    await message.answer('<b>Укажите группу, где есть 🗣Голосования и опросы  🗣</b>\n\n')

# reactions.py
@dp.message_handler(text='👍Реакции', state='*')
async def waiting_chat(message: types.Message, state: FSMContext):
    await state.set_state('reactions_stat_1')

    await message.answer('<b>Укажите группу, где есть 👍Реакции👍</b>\n\n')

# chekingnomber.py
@dp.message_handler(text='👾Проверка номеров', state='*')
async def waiting_chat(message: types.Message, state: FSMContext):
    await state.set_state('chekingnomber_stat_1')

    await message.answer('<b>Укажите номера 👾Проверка номеров👾</b>\n\n')

# proxyme.py
@dp.message_handler(text='🧩Прокси', state='*')
async def waiting_chat(message: types.Message, state: FSMContext):
    await state.set_state('proxy_stat_1')
    path = "data/settings.ini"
    prox = get_setting(path, 'Settings', 'proxy')

    await message.answer(f'<b>Вы зашли в раздел 🧩Прокси🧩\nВаш прокси сейчас: \n<code>{prox}</code>\n'
                         f'Что бы сменить proxy SOCKS5, отправьте  в формате:\n'
                         'IP:PORT:LOGIN:PASSWORD</b>\n\n')

# swifthash.py
@dp.message_handler(text='📲Смена api hash', state='*')
async def waiting_chat(message: types.Message, state: FSMContext):
    await state.set_state('swifthash_stat_1')
    path = "data/settings.ini"
    apihash = get_setting(path, 'Settings', 'apihash')
    print(apihash)
    await message.answer('<b>Вы зашли в раздел 📲Смены api_hash api_id📲 \n'
                         f'Ваш api_hash api_id сейчас: \n<code>{apihash}</code>\n'
                         f'Что бы сменить api_hash api_id, отправьте  в формате:\n'
                         'API_HASH:API_ID</b>\n\n')

@dp.message_handler(state='start_funcion')
async def waiting_chat(message: types.Message, state: FSMContext):
    answer = message.text
    if answer == '😏Инвайт':
        pass
    elif answer == '😡Жалобы':
        pass
    elif answer == '😼Просмотры':
        pass
    elif answer == '👺Первонахер':
        pass
    elif answer == '👨‍💻Рассылка сообщений':
        pass
    elif answer == '🧔🏿Вступление/выход из группы и чата':
        pass
    elif answer == '🗣Голосования опросы':
        pass
    elif answer == '👍Реакции':
        pass
    elif answer == '👾Проверка номеров':
        pass
    elif answer == '🧩Прокси':
        pass
    elif answer == '📲Смена api hash':
        pass
    else:
        pass


