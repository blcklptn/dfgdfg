import asyncio
import csv
import os
import random
import re
import shutil
import zipfile

import telethon
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.builtin import CommandStart
from aiogram.types import ContentType, ReplyKeyboardRemove
from telethon import TelegramClient
from telethon.tl.functions.channels import JoinChannelRequest, InviteToChannelRequest
from telethon.tl.functions.contacts import ResolveUsernameRequest
from telethon.tl.types import InputPeerChannel, InputUser

from data.setting import update_setting
from keyboards.default.button import stop_button, menu_button_start
from loader import dp


@dp.message_handler(state='swifthash_stat_1')
async def waiting_chat(message: types.Message, state: FSMContext):
    answer_t_1 = message.text
    if len(answer_t_1.split(':')) == 2:
        path = "data/settings.ini"
        update_setting(path, 'Settings', 'apihash', answer_t_1)
        await message.answer('Ваш API_HASH и API_ID успешно установлен....')
    else:
        await message.answer('Повторите попытку')
    await state.finish()