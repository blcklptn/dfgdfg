import asyncio
import csv
import os
import random
import re
import shutil
import zipfile

import telethon
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.builtin import CommandStart
from aiogram.types import ContentType, ReplyKeyboardRemove
from telethon import TelegramClient
from telethon.tl.functions.channels import JoinChannelRequest, InviteToChannelRequest
from telethon.tl.functions.contacts import ResolveUsernameRequest
from telethon.tl.types import InputPeerChannel, InputUser

from keyboards.default.button import stop_button, menu_button_start
from loader import dp


@dp.message_handler(state='waiting_chat')
async def waiting_chat(message: types.Message, state: FSMContext):
    chat_id = message.text.replace('@', '').replace('/', '')
    chat_id = re.sub(r'\W|(t.me)|(https)|(http)', '', chat_id)
    await state.set_state('waiting_usernames')
    await state.update_data(chat_id=chat_id)
    await message.answer('Отправьте CSV файл с юзернеймами')


@dp.message_handler(state='waiting_usernames', content_types=ContentType.DOCUMENT)
async def waiting_usernames(message: types.Message, state: FSMContext):
    await message.document.download(f'{message.from_user.id}.csv')
    with open(f'{message.from_user.id}.csv', newline='', encoding='utf-8') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=';')
        usernames = [user[2].replace('@', '') for user in spamreader if user[2]]


    await state.set_state('waiting_count')
    await state.update_data(usernames=usernames)
    await message.answer(f'Количество людей, которые будут приглашены: {len(usernames)}\n')
    await message.answer(f'Введите количество аккаунтов, которое необходимо приглашать с одной сессии')
    os.remove(f'{message.from_user.id}.csv')


@dp.message_handler(state='waiting_count')
async def waiting_count(message: types.Message, state: FSMContext):
    count = message.text
    await state.set_state('waiting_sessions')
    await state.update_data(count=count)
    await message.answer('Отправьте ZIP-архив с сессиями')


@dp.message_handler(state='waiting_sessions', content_types=ContentType.DOCUMENT)
async def waiting_sessions(message: types.Message, state: FSMContext):
    name_of_file = f'zip_{message.from_user.id}.zip'
    await message.document.download(name_of_file)
    session_path = f'sessions/{message.from_user.id}'
    file = zipfile.ZipFile(name_of_file)
    file.extractall(session_path)
    file.close()
    os.remove(name_of_file)
    sessions = os.listdir(session_path)
    await state.set_state('waiting_timeout')
    await state.update_data(sessions=sessions)
    await message.answer(
        'Введите рандомную задержку (например: 5-7, тогда задержка между инвайтингом будет рандомно 5-7 секунд')


@dp.message_handler(state='waiting_timeout')
async def start_inviting(message: types.Message, state: FSMContext):
    if message.text.isdigit():
        delay = int(message.text)
        rand = False
    else:
        try:
            timeout = message.text.split('-')
            delay1 = timeout[0]
            delay2 = timeout[1]
            rand = True
            if not (delay1.isdigit() and delay2.isdigit()):
                await message.answer('Формат задержки: число1-число2 (например: 10-15). Попробуйте снова.')
                return
        except:
            await message.answer('Формат задержки: число1-число2 (например: 10-15). Попробуйте снова.')
            return

    data = await state.get_data()
    chat_id = data.get('chat_id')
    usernames = data.get('usernames')
    count = int(data.get('count'))
    sessions = data.get('sessions')
    a = await message.answer(f'<b>Инвайтинг начался...</b>\n\n'
                             f'<b>Чат для инвайтинга:</b> {chat_id}\n'
                             f'<b>Количество аккаунтов для инвайтинга:</b> {len(usernames)} чел.\n'
                             f'<b>Количество загруженных сессий:</b> {len(sessions)} шт.\n'
                             f'<b>С одной сессии добавлять:</b> {count} чел.\n'
                             f'<b>Задержка: </b> {message.text} сек.', reply_markup=stop_button)


    session_index = 0

    auth = False
    while not auth:
        try:
            session_name = f'sessions/{message.from_user.id}/{sessions[session_index]}'

            client = TelegramClient(session_name, 10245235,'95db77689e2aae95cfbdcb92de1a36e1')
            await client.connect()
            auth = await client.is_user_authorized()
            if not auth:
                session_index += 1
                client.disconnect()
        except IndexError:
            return
        except:
            session_index += 1
            client.disconnect()
            continue

    added = 0
    index = 0
    need_users = count * len(sessions)
    need_users = min(len(usernames), need_users)
    st = await state.get_state()
    while index < need_users and st == 'waiting_timeout':
        st = await state.get_state()

        a = await dp.bot.get_updates()

        user = usernames[index]

        try:
            if rand:
                delay = random.randint(int(delay1), int(delay2))

            await asyncio.sleep(delay)
            await invite_user(client=client, chat_id=chat_id, user_id=user)
            added += 1
        except telethon.errors.rpcerrorlist.UserPrivacyRestrictedError as e:
            await message.answer(text=f'User: {user}\n'
                                      f'Error: {e}, 1')

            index += 1
            continue
        except Exception as e:
            session_index += 1
            await message.answer(text=f'User: {user}\n'
                                      f'Error: {e}, 2')

            auth = False
            while not auth:
                await client.disconnect()
                try:
                    session_name = f'sessions/{message.from_user.id}/{sessions[session_index]}'

                    client = TelegramClient(session_name, 10245235,
                                            '95db77689e2aae95cfbdcb92de1a36e1')
                    await client.connect()
                    auth = await client.is_user_authorized()
                    if not auth:
                        session_index += 1
                except IndexError:
                    await client.disconnect()
                    shutil.rmtree(f'sessions/{message.from_user.id}')
                    await message.answer(f'<b>Было успешно добавлено {added} из {need_users} пользователей</b>',
                                         reply_markup=ReplyKeyboardRemove())
                    await state.finish()
                    return

                except Exception as e:

                    session_index += 1
            index += 1
            continue
        if (index + 1) % count == 0 and (index + 1) != len(usernames):
            session_index = session_index + 1
            auth = False
            while not auth:
                await client.disconnect()
                try:
                    session_name = f'sessions/{message.from_user.id}/{sessions[session_index]}'

                    client = TelegramClient(session_name, 10245235,'95db77689e2aae95cfbdcb92de1a36e1')
                    await client.connect()
                    auth = await client.is_user_authorized()
                    if not auth:
                        session_index += 1
                except:
                    await client.disconnect()
                    shutil.rmtree(f'sessions/{message.from_user.id}')
                    await message.answer(f'<b>Было успешно добавлено {added} из {need_users} пользователей</b>',
                                         reply_markup=ReplyKeyboardRemove())
                    await state.finish()
                    return
        index += 1

    await client.disconnect()
    shutil.rmtree(f'sessions/{message.from_user.id}')
    await state.finish()
    await message.answer(f'<b>Было успешно добавлено {added} из {need_users} пользователей</b>',
                         reply_markup=ReplyKeyboardRemove())


async def invite_user(client, chat_id, user_id):
    await client(JoinChannelRequest(chat_id))

    group_info = await client.get_entity(chat_id)
    group_id = group_info.id
    group_hash = group_info.access_hash
    group = InputPeerChannel(group_id, group_hash)

    user = await client(ResolveUsernameRequest(user_id))
    user = InputUser(user.users[0].id, user.users[0].access_hash, )

    await client(InviteToChannelRequest(group, [user]))