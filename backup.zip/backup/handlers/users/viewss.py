import asyncio
import csv
import os
import random
import re
import shutil
import zipfile

import telethon
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.builtin import CommandStart
from aiogram.types import ContentType, ReplyKeyboardRemove
from telethon import TelegramClient
from telethon.tl import functions
from telethon.tl.functions.channels import JoinChannelRequest, InviteToChannelRequest
from telethon.tl.functions.contacts import ResolveUsernameRequest
from telethon.tl.functions.messages import GetMessagesViewsRequest
from telethon.tl.types import InputPeerChannel, InputUser

from keyboards.default.button import stop_button, menu_button_start
from loader import dp


@dp.message_handler(state='viewss_stat_1')
async def waiting_chat(message: types.Message, state: FSMContext):
    #if message.forward_from_chat:
    #    print(message.forward_from_chat)
    #    await state.update_data(forward_from_chat_id=message.forward_from_chat.id)
    #    await state.update_data(forward_from_chat_username=message.forward_from_chat.username)
     #   await state.set_state('complaints_stat_2')
    #else:
    chat_id = message.text.replace('@', '').replace('/', '')
    chat_id = re.sub(r'\W|(t.me)|(https)|(http)', '', chat_id)
    await state.update_data(chat_id=chat_id)
    await state.set_state('complaints_stat_2')

    await state.set_state('viewss_stat_2')
    await message.answer('Отправьте ZIP-архив с сессиями')


@dp.message_handler(state='viewss_stat_2', content_types=ContentType.DOCUMENT)
async def waiting_chat(message: types.Message, state: FSMContext):
    name_of_file = f'zip_{message.from_user.id}.zip'
    await message.document.download(name_of_file)
    session_path = f'sessions/{message.from_user.id}'
    file = zipfile.ZipFile(name_of_file)
    file.extractall(session_path)
    file.close()
    os.remove(name_of_file)
    sessions = os.listdir(session_path)
    await state.update_data(sessions=sessions)

    data = await state.get_data()

    await message.answer('Просмотры пошли')
    for i in sessions:

        client = TelegramClient(f'sessions/{message.from_user.id}/{i}', 10245235, '95db77689e2aae95cfbdcb92de1a36e1')
        await client.connect()
        auth = await client.is_user_authorized()
        if not auth:
            client.disconnect()
        else:

            mess = await client.get_messages(data['chat_id'],limit=30)
            temp_list = []
            for m in mess:
                temp_list.append(m.id)

            await client(GetMessagesViewsRequest(
                peer=data['chat_id'],
                id=temp_list,
                increment=True
            ))
            client.disconnect()
    await message.answer('Просмотры успешно завершены.')
    await state.finish()

