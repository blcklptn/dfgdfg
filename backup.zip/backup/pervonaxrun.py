import random

from telethon.sync import TelegramClient, events
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.messages import ImportChatInviteRequest

from data.setting import get_setting

path = "data/settings.ini"
chat_id = get_setting(path, "Pervonaxer", "chat_id")
count  = get_setting(path, "Pervonaxer", "count")
sessions  = get_setting(path, "Pervonaxer", "sessions").split(':')
coommments  = get_setting(path, "Pervonaxer", "coommments").split(':')


with TelegramClient(f"sessions/{sessions[0]}", 10245235, '95db77689e2aae95cfbdcb92de1a36e1') as client:
    print("starts")
    chat_id = chat_id.split('~')
    for i in chat_id:
        client(JoinChannelRequest(i))


    @client.on(events.NewMessage(chats=chat_id))
    async def handler(event):
        event = event
        for i in range(0,int(count)):
            index_sess = random.randint(1, len(sessions) - 1)

            client_spam = TelegramClient(f'sessions/{sessions[index_sess]}', 10245235, '95db77689e2aae95cfbdcb92de1a36e1')
            await client_spam.connect()
            auth = await client_spam.is_user_authorized()
            if not auth:
                await client_spam.disconnect()
                while True:
                    index_sess_2 = random.randint(1, len(sessions) - 1)
                    if index_sess_2 != index_sess:

                        client_spam = TelegramClient(f'sessions/{sessions[index_sess_2]}', 10245235,
                                                     '95db77689e2aae95cfbdcb92de1a36e1')
                        await client_spam.connect()
                        auth = await client_spam.is_user_authorized()
                        if not auth:
                            await client_spam.disconnect()
                        else:

                            index_mess = random.randint(0, len(coommments) - 1)
                            try:
                                await client_spam.send_message(entity=event.chat_id, message=coommments[index_mess],
                                                               comment_to=event.message)
                                await client_spam.disconnect()
                                break
                            except Exception as E:
                                print(E)

            else:
                index_mess = random.randint(0, len(coommments) - 1)
                try:
                    await client_spam.send_message(entity=event.chat_id, message=coommments[index_mess],
                                                   comment_to=event.message)

                except Exception as E:
                    print(E)
                await client_spam.disconnect()





    client.run_until_disconnected()



